<?php global $DIRECTORYPRESS_ADIMN_SETTINGS; ?>
<div class="directorypress-content-wrap my-fav_wrap">	
	<?php directorypress_display_template('partials/listing/wrapper.php', array('public_handler' => $public_handler)); ?>
</div>