<?php

directorypress_display_template('partials/templates/reviews.php');