<?php

/**
 * @link       https://designinvento.net/
 * @since      1.0.0
 *
 * @package    DirectoryPress
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
