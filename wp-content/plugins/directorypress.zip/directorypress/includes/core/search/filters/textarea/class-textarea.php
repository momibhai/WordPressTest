<?php 

class directorypress_field_textarea_search extends directorypress_field_text_search {

}
?>