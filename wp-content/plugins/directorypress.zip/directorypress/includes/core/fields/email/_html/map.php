<?php if ($field->value): ?>
	<a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a>
<?php endif; ?>