<?php global $DIRECTORYPRESS_ADIMN_SETTINGS; ?>
<div class="directorypress-content">
	<?php directorypress_renderMessages(); ?>
	<div class="directorypress-submit-section-adv">
		<?php directorypress_login_form(); ?>
	</div>
</div>