<div class="directorypress-content directorypress-submit-block">
	<?php directorypress_renderMessages(); ?>
</div>