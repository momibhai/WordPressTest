<?php directorypress_renderMessages(); ?>
<div class="dasgboard-content-area">
	<?php dpfl_renderTemplate($public_handler->subtemplate, array('public_handler' => $public_handler)); ?>
</div>

