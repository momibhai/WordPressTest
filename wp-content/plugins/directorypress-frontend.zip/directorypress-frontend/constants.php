<?php

define('DIRECTORYPRESS_FSUBMIT_RESOURCES_PATH', DPFL_PATH . 'assets/');
define('DIRECTORYPRESS_FSUBMIT_RESOURCES_URL', plugins_url('/', __FILE__) . 'assets/');
define('DPFL_SHORTCODE', 'directorypress-submit');
define('DPFL_DASHBOARD_SHORTCODE', 'directorypress-dashboard');

